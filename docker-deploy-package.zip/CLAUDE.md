# CLAUDE.md

本文件是 Claude Code 在本仓库中工作的总指令。任何实现、重构、测试、部署脚本修改，都必须优先遵守本文件和 `specs/` 目录下的规格文档。

## 1. 项目目标

构建一个基于 Savant + NVIDIA DeepStream + TensorRT 的多路实时视频分析系统，目标运行环境为一台多线程 CPU、双 NVIDIA T4 GPU 服务器，支持约 60 路 RTSP 视频流。

系统需要支持以下业务能力：

1. 周界入侵
2. 翻墙 / 翻越可疑事件
3. 徘徊
4. 人群聚集
5. 奔跑 / 追逐
6. 摔倒
7. 重点人员布控
8. 轨迹追踪
9. 一键找人

核心技术路线：

```text
Savant + DeepStream + TensorRT
YOLO26-pose
YOLOv8-Face
AdaFace
PostgreSQL + pgvector
Redis Streams
FastAPI
Docker Compose
Prometheus + Grafana
```

## 2. 不可违反的架构原则

### 2.1 Savant 是实时视频主干

Savant module 负责：

- RTSP 视频流进入后的 GPU 解码和 pipeline 处理。
- YOLO26-pose 推理。
- DeepStream nvtracker 跟踪。
- 轻量行为规则判断。
- 生成结构化事件消息。

Savant module 不负责：

- 大量同步数据库写入。
- 慢 HTTP 请求。
- 重型业务查询。
- 大量截图、视频剪辑、文件上传。
- 复杂后台管理逻辑。

慢操作必须通过 Redis Streams 交给 worker 异步处理。

### 2.2 实时系统处理最新帧，不追求处理每一帧

系统不得因为追求每帧检测而堆积无限延迟。发生压力过载时，必须优先：

1. 降低人脸检测频率。
2. 降低非关键摄像头的二级模型频率。
3. 降低 YOLO26-pose FPS。
4. 丢弃过期帧。
5. 保留主行为检测链路。
6. 输出 overload metrics。

### 2.3 统一人脸智能链路

重点人员布控、轨迹追踪、一键找人不能实现成三套独立算法。它们必须复用统一的 Face Intelligence Pipeline：

```text
全帧
  -> YOLO26-pose + nvtracker
  -> YOLOv8-Face (full-frame primary)
  -> face-person association
  -> face quality filter + per-track throttle
  -> AdaFace embedding (in-pipeline, Savant module 内)
  -> Redis security.face_observations
  -> face-worker (CPU only)
  -> PostgreSQL + pgvector
  -> watchlist / observation / live search policy
```

实现要求：

- YOLOv8-Face + AdaFace 在 Savant module 内的接法，优先参考 Savant 官方 `samples/face_reid`。
- 只参考其 detector / landmarks / face alignment / embedding 的模块编排方式。
- 不引入官方 sample 的 `hnswlib` 识别链路作为本项目默认方案。
- 本项目的人脸 observation、向量检索和命中策略统一落在 PostgreSQL + pgvector + `face-worker`。

区别只体现在：

- 重点人员布控：命中名单后产生 `watchlist_hit` 告警。
- 轨迹追踪：清晰人脸入库并关联 camera_id、track_id、timestamp、snapshot。
- 一键找人：用户创建实时搜索任务，命中后产生 `live_search_hit` 告警。

### 2.4 行为规则必须可脱离 Savant 测试

所有行为规则必须被实现为纯 Python 规则模块，不能把核心逻辑写死在 Savant PyFunc 中。

正确分层：

```text
Savant metadata adapter
  -> TrackState / PersonPoseObservation
  -> pure Python rule engine
  -> SecurityEvent
  -> event exporter
```

错误做法：

```text
process_frame() 里直接堆所有规则、数据库、HTTP 和状态逻辑
```

## 3. 目录约定

```text
video-analytics/
  CLAUDE.md

  specs/
    00_project_goal.md
    01_architecture.md
    02_savant_pipeline.md
    03_behavior_rules.md
    04_face_intelligence.md
    05_database_schema.md
    06_api_design.md
    07_deployment.md
    08_performance_policy.md
    09_harness.md

  modules/
    savant_security/
      module.yml
      config/
      custom/
        converters/
        pyfuncs/
        rules/
        models/
        services/

  services/
    api/
    event-worker/
    clip-worker/
    face-worker/

  db/
    migrations/

  infra/
    docker-compose.yml
    prometheus/
    grafana/

  harness/
    tests/
    scenarios/
    golden_events/
```

## 4. 开发规则

1. 修改功能前，先确认对应 `specs/*.md`。
2. 修改规则算法前，先添加或更新 harness 测试。
3. 新增模型时，必须同时记录：
   - 模型来源。
   - 权重许可证。
   - 输入 shape。
   - 输出 tensor shape。
   - converter 行为。
   - TensorRT engine 构建方式。
   - batch size 设计。
4. 不允许在 Savant 主 pipeline 中做阻塞式数据库写入。
5. 不允许在 `process_frame` 中直接做同步大规模向量搜索。
6. 不允许把摄像头 ROI、阈值、RTSP 地址硬编码在算法里。
7. 所有事件必须符合统一 `SecurityEvent` 结构。
8. 所有实时任务必须有 cooldown、过期时间、状态字段和审计记录。

## 5. 推荐开发顺序

以下为初始规划顺序。当前实际进度以 `docs/project_rebaseline_2026_05_25.md` 和 `docs/phase_f1_1a_in_pipeline_face_architecture_lock.md` 为准。

**当前关键偏差：**
- Phase 2 仅完成了 intrusion 规则，loitering / crowd_gathering / fall 未完成。
- Phase 3 实际投入了 Replay / snapshot / annotated media / bbox alignment / ZMQ POC，导致人脸链路晚于原计划。
- 人脸链路现已完成 F1.1a 架构锁定：第一版 detector 为 `YOLOv8-Face full-frame primary`，第一版 embedder 为 `AdaFace in-pipeline`。
- 当前人脸主线已进入 F1.1b / F2 运行时接入阶段；`yolov8_face.onnx` 正在测试，AdaFace 仍待模型资产确认与接线完成。
- Phase 3H ZMQ single-ingestion POC 已验证通过，未来应作为生产拓扑依据。
- Media POC 在 Phase 3H.2 后冻结，不再无限扩展。
- 下一步优先补完缺失行为规则和人脸链路，不再继续新增 media 功能。

### Phase 1: 主视频链路

- YOLO26-pose ONNX/TensorRT 接入。
- Savant module 可启动。
- nvtracker 可生成 track_id。
- 输出 `PersonPoseObservation`。

验收：单路视频可以检测人、关键点、track_id。

### Phase 2: 行为规则

- 周界入侵。
- 徘徊。
- 人群聚集。
- 摔倒初版。

验收：规则可单元测试，Savant 中可生成事件，event-worker 可入库。

### Phase 3 / F1-F3: 人脸链路

- F1.1: YOLOv8-Face full-frame primary detector。
- F1.1/F1.2: face-person association、face quality filter、per-track throttle。
- F2: AdaFace in-pipeline embedding。
- F3: face_observations 入库、pgvector 相似检索、watchlist / live_search 命中事件。

验收：清晰人脸可输出 bbox、5 landmarks、quality、embedding，并能在 PostgreSQL + pgvector 中完成 observation 入库与检索命中。

### Phase 4: 重点人员布控

- persons。
- person_gallery_embeddings。
- watchlist_rules。
- watchlist_hit event。

验收：注册一张人脸，视频出现该人后产生告警。

### Phase 5: 一键找人

- live_search_jobs。
- 实时匹配。
- live_search_hit。
- 前端实时提示当前 camera_id / location / snapshot。

## 6. 测试命令约定

在实际代码生成后，应提供这些命令：

```bash
pytest harness/tests/test_intrusion.py
pytest harness/tests/test_loitering.py
pytest harness/tests/test_crowd_gathering.py
pytest harness/tests/test_running.py
pytest harness/tests/test_fall.py
pytest harness/tests/test_face_vector_store.py
pytest harness/tests/test_live_search.py
```

性能测试：

```bash
bash harness/run_perf_matrix.sh
```

## 7. 验收标准

### 功能验收

- 单路视频可输出 person bbox、keypoints、track_id。
- 行为规则可产生结构化事件。
- 人脸链路可生成 embedding 并入库。
- 重点人员命中后产生 `watchlist_hit`。
- 一键找人任务命中后产生 `live_search_hit`。

### 稳定性验收

- 60 路视频以降帧模式运行时，事件延迟不应无限增长。
- Redis Streams 不应持续堆积。
- PostgreSQL 写入延迟应可监控。
- GPU 显存应稳定，不得持续泄漏。

### 代码质量验收

- 行为规则有纯 Python 单元测试。
- 向量检索有 pgvector 测试。
- Savant pipeline 有 smoke test。
- 所有 worker 可重复消费或具备幂等处理策略。

---

# 8. MVP 报警录像边界

MVP 阶段不得把复杂报警录像作为第一阶段阻塞项。

开发实现必须遵守：

```text
1. event-worker 只做事件入库、告警派发和媒体状态预留。
2. event-worker 不录视频、不拉 RTSP、不等待视频生成。
3. MVP 阶段允许 snapshot_path / clip_path 为空。
4. events.payload.media 必须标记 snapshot_status / clip_status / recording_strategy。
5. 大屏和 API 必须兼容没有视频片段的事件。
6. 不默认实现同一路摄像头双路拉流。
7. 不默认实现持续切片落盘缓存。
```

后续报警片段录制作为独立阶段实现，优先考虑：

```text
savant_replay
external_nvr_replay
```

临时 `post_event_rtsp_demo` 只允许用于演示或调试，不作为生产默认方案。

### 8.1 Savant Replay 录像边界

后续实现报警前后视频片段时，必须优先评估和采用 Savant Replay Service：

```text
RTSP Source Adapter
  -> Replay Service
  -> Savant Module
  -> event-worker / record_request
  -> clip-worker 调 Replay REST API
  -> Video File Sink Adapter
  -> media-worker 回写 clip_path
```

实现要求：

1. 不默认拉第二路 RTSP。
2. 不默认 60 路持续切片落盘。
3. 不优先自研 RecordingController / ring buffer。
4. 事件消息应兼容 `source_id`、`event_ts_ms`、`frame_uuid`、`keyframe_uuid`。
5. clip-worker 创建 Replay job 时应支持 `offset.seconds = DEFAULT_PRE_SECONDS`。
6. Replay / Video File Sink / media-worker 失败不得影响事件入库和告警推送。

---

# 9. 生产视频接入与 Replay 拓扑硬约束

本节是**硬性架构边界**，任何涉及视频接入、Replay、bbox/snapshot 对齐的实现和修改都必须遵守本节规则。

## 9.1 核心原则

1. **生产环境不允许同一路摄像头被 Savant 和 Replay 分别独立拉流。**
2. **生产目标是 single-ingestion：每路摄像头只接入一次。**
3. **任何“双消费者同时消费同一 RTSP”方案只能作为临时验证拓扑，不允许作为生产默认方案。**

## 9.2 推荐目标拓扑（生产）

```text
RTSP camera
  -> Savant Source Adapter  (官方 adapter，独立容器)
    -> Replay Service        (RocksDB 短时缓存，REST API 控制重推)
      -> Savant Module       (GPU 推理，YOLO26-pose + nvtracker + behavior rules)
        -> Redis events
          -> event-worker / clip-worker / video-file-sink / media-worker
```

此拓扑保证 Savant 和 Replay 消费**同一条帧流**，bbox 和 snapshot 天然对齐。

## 9.3 当前 Phase 3B/3F0 临时拓扑（仅用于验证）

当前 `infra/docker-compose.phase3b.yml` 使用以下临时拓扑：

```text
testVideo/test.mp4
  -> ffmpeg-source -> RTSP server -> Savant (uridecodebin)
  -> source-adapter -> ZMQ -> Replay Service
```

这是**双文件独立循环**，Savant 和 Replay 各自独立读取 test.mp4，不在同一帧。此拓扑：

- 仅允许作为 **MVP 功能验证和开发测试**。
- **不允许** 作为生产部署方案。
- **不允许** 在 bbox/snapshot 对齐验证中声称"视觉通过"。

Phase 3F0.3a 提议的"同 RTSP 双消费者"方案（Savant + source-adapter 都读同一个 RTSP）仅能**减少**双文件循环错位，**不能保证帧级对齐**。

## 9.4 Bbox/Snapshot 对齐的硬性前提

如果 bbox/snapshot 对齐要求严格（生产环境），必须解决以下**全部三项**：

1. **单输入拓扑** — Savant 和 Replay 必须消费同一条帧流（single-ingestion）。
2. **时间域映射** — Savant 的 NTP/PTS 时间戳与 Replay 的 pipeline-relative 时间戳必须建立映射关系。
3. **帧级对齐字段** — `frame_uuid`、`keyframe_uuid`、`frame_num`、`pts` 等字段必须在 event payload 中正确填充，并在 Replay keyframe lookup 中使用。

**在上述三项全部解决之前，真实 bbox overlay 不得作为生产视觉验收通过。**

## 9.5 禁止行为（硬约束）

以下行为**严格禁止**在任何阶段引入：

1. 同一路摄像头双 RTSP 拉流作为生产方案。
2. 60 路持续切片落盘（全量录制）。
3. 无限制事件全量 media generation（没有 cooldown / severity policy）。
4. 没有 cooldown / severity policy 的全量 snapshot/clip 生成。
5. 在 `process_frame` 中直接做阻塞式数据库写入或同步 HTTP 调用。
6. 把摄像头 ROI、阈值、RTSP 地址硬编码在算法代码中。
7. 把 bbox overlay 标记为"生产已验证"在 timestamp-domain mapping 完成之前。

## 9.6 允许的临时措施

以下措施在 MVP/开发阶段**明确允许**：

1. source-adapter + Savant 分别消费同一 RTSP 源（方案 B），仅用于减少双文件错位 — **不声称帧级对齐**。
2. 禁用真实 bbox overlay（方案 D），只保留 label overlay — **保守但安全**。
3. Replay keyframe lookup 使用 unbounded search — **当前已知限制，记录在文档中**。
4. `frame_uuid` / `keyframe_uuid` 为 `None` — **当前已知限制，后续补齐**。

## 9.7 相关文档

- `docs/production_ingestion_topology_policy.md` — 生产拓扑策略正式文件（必读）
- `docs/phase3f0_2_diagnosis_report.md` — bbox/snapshot 对齐诊断报告
- `docs/phase3f0_3_topology_review.md` — 拓扑方案详细对比
- `specs/01_architecture.md` — 架构规格
- `specs/11_docker_communication_and_clip_design.md` — 容器通信与录像设计
