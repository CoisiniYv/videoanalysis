# Docker 部署包说明

本包包含 c1-official-adapter 栈的所有 Docker 配置和运行代码。

## 包内容

### Docker Compose
- `infra/docker-compose.c1-official-adapter.yml` — 主 compose 文件，定义 8 个容器

### Savant 推理模块（bind mount，改代码重启即生效）
- `modules/savant_security/module.yml` — pipeline 定义
- `modules/savant_security/custom/pyfuncs/` — 行为人脸 PyFunc
- `modules/savant_security/custom/converters/` — 模型输出转换器
- `modules/savant_security/custom/rules/` — 行为规则引擎
- `modules/savant_security/custom/models/` — 数据模型
- `modules/savant_security/custom/services/` — 业务服务
- `modules/savant_security/config/` — 摄像头和 tracker 配置

### Event Worker（build 进镜像，改代码需重新 build）
- `services/event-worker/` — Redis 事件 → PostgreSQL

### Face Worker（build 进镜像，改代码需重新 build）
- `services/face-worker/` — 人脸 observations → pgvector 检索 → watchlist 命中

### API（build 进镜像，改代码需重新 build）
- `services/api/` — FastAPI 事件查询 + 媒体文件服务

### 数据库迁移
- `db/migrations/` — PostgreSQL 初始化 SQL（001-009）

### Replay 配置（当前未启用）
- `modules/savant_replay/config.json` — Savant Replay Service 配置

### 文档
- `CLAUDE.md` — 项目总指令
- `specs/00_project_goal.md` — 项目目标
- `specs/01_architecture.md` — 架构设计
- `specs/02_savant_pipeline.md` — Savant pipeline 规格
- `specs/05_database_schema.md` — 数据库 schema
- `specs/07_deployment.md` — 部署规格

## 容器架构

```
外部 source adapter (camera_source_controller 启动)
  → ZMQ DEALER → savant-security ROUTER bind (5555)
    → YOLO26-pose / nvtracker / BehaviorRulesPyFunc
      → Redis security.events → event-worker → PostgreSQL
    → YOLOv8-Face / AdaFace / FaceObservationExporter
      → Redis security.face_observations → face-worker → PostgreSQL
    → ZMQ sink pub+bind (5556)
      → metadata-sink → NDJSON 文件
      → video-file-sink → 视频文件
  → api (端口 8004)
```

## 端口映射

| 服务 | 宿主机端口 | 容器端口 |
|------|-----------|---------|
| Redis | 6385 | 6379 |
| PostgreSQL | 5438 | 5432 |
| Savant ZMQ src | 5555 | 5555 |
| Savant ZMQ sink | 5556 | 5556 |
| API | 8004 | 8000 |

## 启动方式

```bash
cd infra
docker compose -f docker-compose.c1-official-adapter.yml up -d
```

## 重新构建（修改 event-worker / face-worker / api 代码后）

```bash
cd infra
docker compose -f docker-compose.c1-official-adapter.yml build event-worker face-worker api
docker compose -f docker-compose.c1-official-adapter.yml up -d
```

## Savant 模块修改（bind mount，重启即生效）

```bash
docker restart c1-official-savant
```

## 需要的外部文件（未包含在包中）

- `/data/video-analytics/models/` — ONNX 模型权重
  - `yolo26_pose/yolo26_pose.onnx`
  - `yolov8_face.onnx`
  - `adaface/adaface_ir50_webface4m.onnx`
- `/data/video-analytics/media/` — 媒体输出目录
- `testVideo/` — 测试视频文件
